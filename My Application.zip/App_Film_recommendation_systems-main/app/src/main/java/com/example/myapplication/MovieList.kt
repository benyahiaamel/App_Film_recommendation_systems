package com.example.myapplication

import android.content.Context
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.opencsv.CSVReader

@Composable
fun MovieList(
    navController: NavController,
    viewModel: RecommendationViewModel,
    searchQuery: String,
    selectedGenre: String?,
    selectedYear: String?,
    selectedRating: String?,
    selectedDuration: String?
) {
    val context = LocalContext.current

    // Charger les films et voisins une seule fois
    var movies by remember { mutableStateOf<List<Movie>>(emptyList()) }
    var neighbors by remember { mutableStateOf<List<List<Int>>>(emptyList()) }

    LaunchedEffect(Unit) {
        movies = getSampleMovies(context)
        neighbors = loadSparseKnnMatrix(context)

        // Mettre à jour le ViewModel
        viewModel.updateMoviesList(movies)
        viewModel.updateNeighbors(neighbors)
    }

    // 🔥 Filtrage combiné + Top films par défaut
    val filteredMovies = if (
        searchQuery.isEmpty() &&
        selectedGenre == null &&
        selectedYear == null &&
        selectedRating == null &&
        selectedDuration == null
    ) {
        // 🔹 Aucun filtre / recherche actif → films tendances (Top Rating)
        movies.sortedByDescending { it.rating }.take(10) // par ex. top 10
    } else {
        // 🔹 Recherche / filtres actifs
        movies.filter { movie ->
            movie.title.startsWith(searchQuery, ignoreCase = true)
                    && (selectedGenre == null || movie.genre.contains(selectedGenre, ignoreCase = true))
                    && (selectedYear == null || formatYearInterval(movie.date) == selectedYear)
                    && (selectedRating == null || when(selectedRating) {
                "1 ⭐" -> movie.rating < 2.5
                "2 ⭐" -> movie.rating >= 2.5 && movie.rating < 5.0
                "3 ⭐" -> movie.rating >= 5.0 && movie.rating < 7.0
                "4 ⭐" -> movie.rating >= 7.0
                else -> true
            })
                    && (selectedDuration == null || formatDurationInterval(movie.duration) == selectedDuration)
        }
    }

    LazyColumn(
        modifier = Modifier.padding(horizontal = 16.dp)
    ) {
        // Banner en premier
        item { CarouselBanner() }

        // Films filtrés
        items(filteredMovies) { movie ->
            MovieCard(movie, navController, neighbors, viewModel)
        }
    }
}


fun formatYearInterval(yearString: String): String {
    val year = yearString.toIntOrNull() ?: return "Inconnu"
    return when (year) {
        in 2020..2022 -> "2020-2022"
        in 2015..2019 -> "2015-2019"
        in 2010..2014 -> "2010-2014"
        in 2005..2009 -> "2005-2009"
        in 2000..2004 -> "2000-2004"
        in 1995..1999 -> "1995-1999"
        in 1990..1994 -> "1990-1994"
        in 1985..1989 -> "1985-1989"
        in 1980..1984 -> "1980-1984"
        in 1975..1979 -> "1975-1979"
        in 1970..1974 -> "1970-1974"
        in 1965..1969 -> "1965-1969"
        in 1960..1964 -> "1960-1964"
        in 1955..1959 -> "1955-1959"
        in 1950..1954 -> "1950-1954"
        in 1945..1949 -> "1945-1949"
        in 1940..1944 -> "1940-1944"
        in 1935..1939 -> "1935-1939"
        in 1930..1934 -> "1930-1934"
        in 1925..1929 -> "1925-1929"
        in 1920..1924 -> "1920-1924"
        else -> "Avant 1920"
    }
}


fun formatDurationInterval(durationMinutes: String): String {
    val minutes = durationMinutes.toIntOrNull() ?: return "Inconnu"
    return when {
        minutes <= 60 -> "0-1h"
        minutes <= 120 -> "1-2h"
        minutes <= 180 -> "2-3h"
        minutes <= 240 -> "3-4h"
        else -> "4h+"
    }
}
// Extension pour mettre à jour les voisins dans le ViewModel
private fun RecommendationViewModel.updateNeighbors(neighbors: List<List<Int>>) {}

// Fonctions pour charger les données depuis assets
fun getSampleMovies(context: Context): List<Movie> {
    val moviesList = mutableListOf<Movie>()
    val inputStream = context.assets.open("IMDB_db.csv")
    val reader = CSVReader(inputStream.bufferedReader())
    reader.skip(1)
    var index = 0
    reader.forEach { tokens ->
        try {
            if (tokens.size > 9) {
                val title = tokens[0]
                val image = tokens[1]
                val genre = tokens[5]
                val date = tokens[9]
                val description = tokens[2]
                val rating = tokens[11].toFloatOrNull() ?: 0f
                val duration = tokens[12]
                moviesList.add(
                    Movie(
                        id = index,
                        title = title,
                        rating = rating,
                        image = image,
                        duration = duration,
                        genre = genre,
                        date = date,
                        description = description
                    )
                )
                index++
            }
        } catch (e: Exception) {}
    }
    return moviesList
}

fun loadSparseKnnMatrix(context: Context, filename: String = "neighbors.json"): List<List<Int>> {
    val inputStream = context.assets.open(filename)
    val jsonString = inputStream.bufferedReader().use { it.readText() }
    val jsonArray = org.json.JSONArray(jsonString)
    val neighbors = mutableListOf<List<Int>>()
    for (i in 0 until jsonArray.length()) {
        val rowArray = jsonArray.getJSONArray(i)
        val rowList = mutableListOf<Int>()
        for (j in 0 until rowArray.length()) {
            rowList.add(rowArray.getInt(j))
        }
        neighbors.add(rowList)
    }
    return neighbors
}
