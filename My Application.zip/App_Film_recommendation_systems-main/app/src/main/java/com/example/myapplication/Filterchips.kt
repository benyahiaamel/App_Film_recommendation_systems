package com.example.myapplication

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FilterChips(
    onGenreChange: (String?) -> Unit,
    onYearChange: (String?) -> Unit,
    onRatingChange: (String?) -> Unit,
    onDurationChange: (String?) -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Genre
        FilterChipMenu(
            label = "Genre",
            options = listOf("Tous") + listOf("Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Drama", "Fantasy", "Film-Noir", "History", "Horror", "Musical", "Mystery", "Romance", "Sci-Fi", "Sport", "Thriller", "War"),
            onSelected = { onGenreChange(if (it == "Tous") null else it) }
        )

        // Année
        FilterChipMenu(
            label = "Année",
            options = listOf(
                "Toutes",
                "2020-2022", "2015-2019", "2010-2014", "2005-2009", "2000-2004",
                "1995-1999", "1990-1994", "1985-1989", "1980-1984", "1975-1979",
                "1970-1974", "1965-1969", "1960-1964", "1955-1959", "1950-1954",
                "1945-1949", "1940-1944", "1935-1939", "1930-1934", "1925-1929",
                "1920-1924", "Avant 1920"
            ),
            onSelected = { onYearChange(if (it == "Toutes") null else it) }
        )


        // Note
        FilterChipMenu(
            label = "Note",
            options = listOf("Toutes", "1 ⭐", "2 ⭐", "3 ⭐", "4 ⭐"),
            onSelected = { onRatingChange(if (it == "Toutes") null else it) }
        )



        // Durée
        FilterChipMenu(
            label = "Durée",
            options = listOf("Toutes", "0-1h", "1-2h", "2-3h", "3-4h", "4h+"),
            onSelected = { onDurationChange(if (it == "Toutes") null else it) }
        )

    }
}
