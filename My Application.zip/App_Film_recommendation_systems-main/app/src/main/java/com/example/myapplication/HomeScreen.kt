package com.example.myapplication

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    navController: NavController,
    viewModel: RecommendationViewModel
) {
    var searchQuery by remember { mutableStateOf("") }
    var showMovies by remember { mutableStateOf(true) }

    // États des filtres
    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var selectedYear by remember { mutableStateOf<String?>(null) }
    var selectedRating by remember { mutableStateOf<String?>(null) }
    var selectedDuration by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(bottom = 60.dp)
    ) {
        // Barre de recherche fixe
        SearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it }
        )

        // Barre de filtres horizontale fixe
        FilterChips(
            onGenreChange = { selectedGenre = it },
            onYearChange = { selectedYear = it },
            onRatingChange = { selectedRating = it },
            onDurationChange = { selectedDuration = it }
        )

        // Barre de tendance / recommandations fixe
        TendanceTitle { expanded ->
            showMovies = expanded
        }

        // Liste défilante
        if (showMovies) {
            MovieList(
                navController = navController,
                viewModel = viewModel,
                searchQuery = searchQuery,
                selectedGenre = selectedGenre,
                selectedYear = selectedYear,
                selectedRating = selectedRating,
                selectedDuration = selectedDuration
            )
        }
    }
}
